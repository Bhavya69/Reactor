package com.deswaef.spring.examples.reactor.model;

/**
 * User: Quinten
 * Date: 6-9-2014
 * Time: 01:39
 *
 * @author Quinten De Swaef
 */
public enum LogCategory {
    DEBUG, ERROR, INFO
}
